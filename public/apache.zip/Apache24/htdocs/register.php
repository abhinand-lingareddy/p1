<html>
<body>

<form action="register_user.php" method="post">
Name: <input type="text" name="name"><br>
E-mail: <input type="text" name="email"><br>
dob: <input type="text" name="dob"><br>
password: <input type="password" name="password"><br>
confirm password: <input type="password" name="confirm_password"><br>
<input type="submit">
</form>

</body>
</html>