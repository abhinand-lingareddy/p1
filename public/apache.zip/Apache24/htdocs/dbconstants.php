<?php
define("servername", "localhost:3307");
define("username", "root");
define("dbpassword", NULL);
define("dbname", "connections");


?>