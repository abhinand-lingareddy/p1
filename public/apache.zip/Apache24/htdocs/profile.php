<?php
session_start();
if(!isset($_SESSION['id']))
{
	header("location: login.php");
}
require 'dbconstants.php';

try
{
	$servername = servername;
	$dbusername = username;
	$dbpassword = dbpassword;
	$dbname = dbname;

	$username=$_SESSION["username"];
	$id=$_SESSION["id"];
	echo "id ",$id;


	// Create connection
	$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}

	$stmt = $conn->prepare("SELECT name,email,dob,achivements FROM account where id=? ");
	$stmt->bind_param("i", $id);

	$result = $stmt->execute();
	$stmt->bind_result($name,$email,$dob,$ach);
	if($stmt->fetch()){
		echo "sucess",$dob;
	}
	else {
		echo "failure";
	}

}

catch (Exception $e) {
	//error
}
finally{
	$conn->close();
}



?>