<html>
<body>

<form action="login_user.php" method="post">
E-mail: <input type="text" name="email"><br>
password: <input type="password" name="password"><br>
<input type="submit">
</form>

</body>
</html>